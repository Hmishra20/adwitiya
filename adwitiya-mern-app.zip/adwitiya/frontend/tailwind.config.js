/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        rose: {
          50: '#fff1f2',
          100: '#ffe4e6',
          500: '#f43f5e',
          600: '#e11d48',
          700: '#be123c',
          900: '#881337',
        },
      },
      animation: {
        'pulse-ring': 'pulse-ring 1.5s cubic-bezier(0.215, 0.61, 0.355, 1) infinite',
        'sos-pulse': 'sos-pulse 1s ease-in-out infinite alternate',
      },
      keyframes: {
        'pulse-ring': {
          '0%': { transform: 'scale(0.9)', opacity: 1 },
          '100%': { transform: 'scale(2)', opacity: 0 },
        },
        'sos-pulse': {
          '0%': { boxShadow: '0 0 0 0px rgba(220, 38, 38, 0.7)' },
          '100%': { boxShadow: '0 0 0 20px rgba(220, 38, 38, 0)' },
        },
      },
    },
  },
  plugins: [],
};
