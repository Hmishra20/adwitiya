import React, { useState, useRef } from 'react';
import toast from 'react-hot-toast';
import api from '../services/api';

export default function SOSButton({ journeyId, position, onSOSTriggered }) {
  const [isActive, setIsActive] = useState(false);
  const [countdown, setCountdown] = useState(null);
  const [triggering, setTriggering] = useState(false);
  const holdTimerRef = useRef(null);
  const countdownRef = useRef(null);
  const HOLD_DURATION = 3; // 3 second hold

  const startHold = () => {
    let count = HOLD_DURATION;
    setCountdown(count);

    countdownRef.current = setInterval(() => {
      count -= 1;
      setCountdown(count);
      if (count <= 0) {
        clearInterval(countdownRef.current);
        triggerSOS();
      }
    }, 1000);

    holdTimerRef.current = setTimeout(() => {}, HOLD_DURATION * 1000);
  };

  const cancelHold = () => {
    clearInterval(countdownRef.current);
    clearTimeout(holdTimerRef.current);
    setCountdown(null);
  };

  const triggerSOS = async () => {
    setCountdown(null);
    setTriggering(true);
    setIsActive(true);

    try {
      const lat = position?.latitude || 0;
      const lng = position?.longitude || 0;

      const { data } = await api.post('/alerts/sos', {
        lat,
        lng,
        accuracy: position?.accuracy,
        journeyId,
        message: 'SOS triggered via Adwitiya app',
      });

      toast.success(
        <div>
          <p className="font-bold">SOS Alert Sent!</p>
          <p className="text-sm">SMS: {data.notifications.sms.sent ? '✅' : '❌'} | Email: {data.notifications.email.sent ? '✅' : '❌'}</p>
        </div>,
        { duration: 6000 }
      );

      if (onSOSTriggered) onSOSTriggered(data.alert);
    } catch (err) {
      toast.error('SOS failed. Call 112 immediately!');
      setIsActive(false);
    } finally {
      setTriggering(false);
    }
  };

  const deactivateSOS = () => {
    setIsActive(false);
    toast('SOS deactivated. Stay safe!', { icon: '✅' });
  };

  if (isActive) {
    return (
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-red-500 opacity-30 animate-ping scale-150"></div>
          <div className="absolute inset-0 rounded-full bg-red-500 opacity-20 animate-ping scale-125" style={{ animationDelay: '0.5s' }}></div>
          <button
            onClick={deactivateSOS}
            className="relative w-32 h-32 rounded-full bg-red-600 text-white font-bold text-lg shadow-2xl sos-active border-4 border-red-400 z-10"
          >
            <span className="text-3xl">🚨</span>
            <br />
            <span className="text-xs">SOS ACTIVE</span>
            <br />
            <span className="text-xs opacity-80">Tap to cancel</span>
          </button>
        </div>
        <p className="text-red-600 font-semibold animate-pulse text-sm">
          Emergency alert sent to your contacts
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        {countdown && (
          <div className="absolute inset-0 rounded-full border-4 border-red-400 animate-ping opacity-75"></div>
        )}
        <button
          onMouseDown={startHold}
          onMouseUp={cancelHold}
          onMouseLeave={cancelHold}
          onTouchStart={startHold}
          onTouchEnd={cancelHold}
          disabled={triggering}
          className={`relative w-32 h-32 rounded-full text-white font-bold shadow-2xl transition-all duration-200 z-10 sos-button ${
            countdown
              ? 'bg-red-700 scale-95 border-4 border-red-300'
              : 'bg-red-600 hover:bg-red-700 border-4 border-red-400'
          } ${triggering ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer active:scale-95'}`}
        >
          {triggering ? (
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 border-3 border-white border-t-transparent rounded-full animate-spin mb-1"></div>
              <span className="text-xs">Sending...</span>
            </div>
          ) : countdown ? (
            <div className="flex flex-col items-center">
              <span className="text-4xl font-black">{countdown}</span>
              <span className="text-xs">Release to cancel</span>
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <span className="text-3xl">🆘</span>
              <span className="text-sm font-black">SOS</span>
              <span className="text-xs opacity-80">Hold 3s</span>
            </div>
          )}
        </button>
      </div>
      <p className="text-gray-500 text-xs text-center max-w-[200px]">
        Hold for 3 seconds to send emergency alert to your contacts
      </p>
    </div>
  );
}
