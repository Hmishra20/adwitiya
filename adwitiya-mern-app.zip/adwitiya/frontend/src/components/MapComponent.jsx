import React, { useCallback, useRef, useState } from 'react';
import { GoogleMap, useJsApiLoader, Marker, Polyline, InfoWindow } from '@react-google-maps/api';

const LIBRARIES = ['places'];

const mapStyles = [
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#e9e9e9' }] },
  { featureType: 'landscape', elementType: 'geometry', stylers: [{ color: '#f5f5f5' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#ffffff' }] },
  { featureType: 'poi', elementType: 'geometry', stylers: [{ color: '#eeeeee' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#e5e5e5' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#ffffff' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#9e9e9e' }] },
];

export default function MapComponent({
  currentPosition,
  origin,
  destination,
  liveTrail = [],
  polylinePath = [],
  riskLevel,
}) {
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    libraries: LIBRARIES,
  });

  const mapRef = useRef(null);
  const [selectedMarker, setSelectedMarker] = useState(null);

  const onLoad = useCallback((map) => {
    mapRef.current = map;
  }, []);

  const center = currentPosition
    ? { lat: currentPosition.latitude, lng: currentPosition.longitude }
    : origin
    ? { lat: origin.lat, lng: origin.lng }
    : { lat: 28.6139, lng: 77.209 }; // Default: Delhi

  const riskColor = riskLevel === 'High' ? '#dc2626' : riskLevel === 'Moderate' ? '#f59e0b' : '#10b981';

  if (loadError) return (
    <div className="w-full h-64 bg-gray-100 rounded-xl flex items-center justify-center text-gray-500">
      <div className="text-center">
        <p className="text-2xl mb-2">🗺️</p>
        <p className="text-sm">Failed to load map. Check your API key.</p>
      </div>
    </div>
  );

  if (!isLoaded) return (
    <div className="w-full h-64 bg-gray-100 rounded-xl flex items-center justify-center animate-pulse">
      <p className="text-gray-400">Loading map...</p>
    </div>
  );

  return (
    <GoogleMap
      mapContainerClassName="w-full h-full rounded-xl"
      center={center}
      zoom={15}
      onLoad={onLoad}
      options={{
        styles: mapStyles,
        disableDefaultUI: false,
        zoomControl: true,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: true,
      }}
    >
      {/* Current live position */}
      {currentPosition && (
        <Marker
          position={{ lat: currentPosition.latitude, lng: currentPosition.longitude }}
          icon={{
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 10,
            fillColor: '#e11d48',
            fillOpacity: 1,
            strokeColor: '#fff',
            strokeWeight: 3,
          }}
          title="Your Location"
          onClick={() => setSelectedMarker('current')}
        />
      )}

      {/* Origin marker */}
      {origin && (
        <Marker
          position={{ lat: origin.lat, lng: origin.lng }}
          label={{ text: 'A', color: 'white', fontWeight: 'bold' }}
          title="Origin"
        />
      )}

      {/* Destination marker */}
      {destination && (
        <Marker
          position={{ lat: destination.lat, lng: destination.lng }}
          label={{ text: 'B', color: 'white', fontWeight: 'bold' }}
          title="Destination"
        />
      )}

      {/* Route polyline */}
      {polylinePath.length > 1 && (
        <Polyline
          path={polylinePath}
          options={{
            strokeColor: riskColor,
            strokeOpacity: 0.8,
            strokeWeight: 5,
          }}
        />
      )}

      {/* Live trail polyline */}
      {liveTrail.length > 1 && (
        <Polyline
          path={liveTrail.map((c) => ({ lat: c.lat, lng: c.lng }))}
          options={{
            strokeColor: '#e11d48',
            strokeOpacity: 0.6,
            strokeWeight: 3,
            icons: [{ icon: { path: window.google.maps.SymbolPath.FORWARD_CLOSED_ARROW }, offset: '100%' }],
          }}
        />
      )}

      {selectedMarker === 'current' && currentPosition && (
        <InfoWindow
          position={{ lat: currentPosition.latitude, lng: currentPosition.longitude }}
          onCloseClick={() => setSelectedMarker(null)}
        >
          <div className="p-1 text-sm">
            <p className="font-bold text-rose-600">📍 Your Location</p>
            <p className="text-gray-600">{currentPosition.latitude.toFixed(5)}, {currentPosition.longitude.toFixed(5)}</p>
            {currentPosition.accuracy && <p className="text-gray-500 text-xs">Accuracy: ±{Math.round(currentPosition.accuracy)}m</p>}
          </div>
        </InfoWindow>
      )}
    </GoogleMap>
  );
}
