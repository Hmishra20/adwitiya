import React from 'react';

const getRiskColor = (level) => {
  switch (level) {
    case 'Safe': return { bg: 'bg-emerald-50', border: 'border-emerald-200', text: 'text-emerald-700', bar: 'bg-emerald-500', icon: '✅' };
    case 'Moderate': return { bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-700', bar: 'bg-amber-500', icon: '⚠️' };
    case 'High': return { bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-700', bar: 'bg-red-500', icon: '🚨' };
    default: return { bg: 'bg-gray-50', border: 'border-gray-200', text: 'text-gray-700', bar: 'bg-gray-400', icon: '❓' };
  }
};

export default function RiskScoreCard({ riskData, loading }) {
  if (loading) {
    return (
      <div className="card animate-pulse">
        <div className="h-4 bg-gray-200 rounded w-1/3 mb-4"></div>
        <div className="h-8 bg-gray-200 rounded w-1/2 mb-3"></div>
        <div className="h-2 bg-gray-200 rounded w-full"></div>
      </div>
    );
  }

  if (!riskData) return null;

  const { score, level, factors, routeData } = riskData;
  const colors = getRiskColor(level);

  return (
    <div className={`rounded-xl border-2 ${colors.border} ${colors.bg} p-4`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-gray-700 text-sm uppercase tracking-wide">Route Risk Analysis</h3>
        <span className="text-lg">{colors.icon}</span>
      </div>

      {/* Score */}
      <div className="flex items-end gap-3 mb-3">
        <span className={`text-5xl font-black ${colors.text}`}>{score}</span>
        <div className="pb-1">
          <span className={`text-lg font-bold ${colors.text}`}>{level}</span>
          <p className="text-xs text-gray-500">Risk Level</p>
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
        <div
          className={`h-2.5 rounded-full transition-all duration-500 ${colors.bar}`}
          style={{ width: `${score}%` }}
        ></div>
      </div>

      {/* Route info */}
      {routeData && (
        <div className="grid grid-cols-2 gap-3 mb-3">
          <div className="bg-white/70 rounded-lg p-2 text-center">
            <p className="text-xs text-gray-500">Distance</p>
            <p className="font-semibold text-gray-800 text-sm">{routeData.distance}</p>
          </div>
          <div className="bg-white/70 rounded-lg p-2 text-center">
            <p className="text-xs text-gray-500">Duration</p>
            <p className="font-semibold text-gray-800 text-sm">{routeData.duration}</p>
          </div>
        </div>
      )}

      {/* Factors */}
      {factors && (
        <div className="space-y-1.5">
          <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Risk Factors</p>
          {[
            { label: 'Distance', value: factors.distanceFactor, max: 50 },
            { label: 'Travel Time', value: factors.timeFactor, max: 50 },
            { label: 'Isolation', value: factors.isolationFactor, max: 70 },
          ].map((f) => (
            <div key={f.label} className="flex items-center gap-2">
              <span className="text-xs text-gray-500 w-20 shrink-0">{f.label}</span>
              <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                <div
                  className={`h-1.5 rounded-full ${colors.bar}`}
                  style={{ width: `${(f.value / f.max) * 100}%` }}
                ></div>
              </div>
              <span className="text-xs font-medium text-gray-600 w-6 text-right">{f.value}</span>
            </div>
          ))}
          {factors.nightMultiplier > 1 && (
            <div className="flex items-center gap-2 mt-2 bg-white/70 rounded-lg px-2 py-1.5">
              <span className="text-sm">🌙</span>
              <span className="text-xs text-orange-600 font-medium">
                Night-time multiplier: {factors.nightMultiplier}x applied
              </span>
            </div>
          )}
          {factors.totalPOIsNearby !== undefined && (
            <div className="flex items-center gap-2 bg-white/70 rounded-lg px-2 py-1.5">
              <span className="text-sm">📍</span>
              <span className="text-xs text-gray-600">
                {factors.totalPOIsNearby} safe places nearby (police, hospital, etc.)
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
