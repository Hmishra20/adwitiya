import { useState, useEffect, useRef, useCallback } from 'react';
import api from '../services/api';

const SEND_INTERVAL = 5000; // 5 seconds

export const useGeolocation = (journeyId = null, enabled = false) => {
  const [position, setPosition] = useState(null);
  const [error, setError] = useState(null);
  const [isTracking, setIsTracking] = useState(false);
  const watchIdRef = useRef(null);
  const intervalRef = useRef(null);
  const latestPositionRef = useRef(null);

  const sendToBackend = useCallback(
    async (coords) => {
      try {
        await api.post('/location/update', {
          lat: coords.latitude,
          lng: coords.longitude,
          accuracy: coords.accuracy,
          journeyId,
        });
      } catch (err) {
        console.warn('Location update failed:', err.message);
      }
    },
    [journeyId]
  );

  const startTracking = useCallback(() => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      return;
    }

    setIsTracking(true);

    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        const coords = {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        };
        setPosition(coords);
        latestPositionRef.current = coords;
      },
      (err) => setError(err.message),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );

    // Send to backend every 5 seconds
    intervalRef.current = setInterval(() => {
      if (latestPositionRef.current) {
        sendToBackend(latestPositionRef.current);
      }
    }, SEND_INTERVAL);
  }, [sendToBackend]);

  const stopTracking = useCallback(() => {
    if (watchIdRef.current) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsTracking(false);
  }, []);

  useEffect(() => {
    if (enabled) {
      startTracking();
    } else {
      stopTracking();
    }
    return () => stopTracking();
  }, [enabled, startTracking, stopTracking]);

  // Get one-time location
  const getCurrentPosition = () =>
    new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ latitude: pos.coords.latitude, longitude: pos.coords.longitude, accuracy: pos.coords.accuracy }),
        (err) => reject(err),
        { enableHighAccuracy: true, timeout: 10000 }
      );
    });

  return { position, error, isTracking, startTracking, stopTracking, getCurrentPosition };
};
