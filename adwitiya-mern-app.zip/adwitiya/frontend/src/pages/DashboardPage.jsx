import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useGeolocation } from '../hooks/useGeolocation';
import SOSButton from '../components/SOSButton';
import MapComponent from '../components/MapComponent';
import api from '../services/api';
import toast from 'react-hot-toast';

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeJourney, setActiveJourney] = useState(null);
  const [recentAlerts, setRecentAlerts] = useState([]);
  const [stats, setStats] = useState({ journeys: 0, alerts: 0 });

  const { position, isTracking } = useGeolocation(
    activeJourney?._id,
    !!activeJourney
  );

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [journeyRes, alertsRes] = await Promise.allSettled([
        api.get('/journey/active'),
        api.get('/alerts?limit=3'),
      ]);

      if (journeyRes.status === 'fulfilled') {
        setActiveJourney(journeyRes.value.data.journey);
      }
      if (alertsRes.status === 'fulfilled') {
        setRecentAlerts(alertsRes.value.data.alerts);
      }
    } catch (err) {
      console.error('Dashboard fetch error', err);
    }
  };

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const isNightTime = new Date().getHours() >= 20 || new Date().getHours() < 6;

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900">
            {greeting()}, {user?.name?.split(' ')[0]} 👋
          </h1>
          <p className="text-gray-500 text-sm mt-1">
            {isNightTime ? '🌙 Night-time safety mode active' : '☀️ Stay aware of your surroundings'}
          </p>
        </div>
        {isTracking && (
          <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-full px-3 py-1.5">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="text-xs font-medium text-emerald-700">Tracking</span>
          </div>
        )}
      </div>

      {/* Night warning */}
      {isNightTime && (
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-3 flex items-center gap-3">
          <span className="text-2xl">🌙</span>
          <div>
            <p className="font-semibold text-orange-700 text-sm">Night-time alert</p>
            <p className="text-orange-600 text-xs">Risk scores are elevated. Share your journey with contacts.</p>
          </div>
        </div>
      )}

      {/* Emergency contacts warning */}
      {user?.emergencyContacts?.length === 0 && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">⚠️</span>
            <div>
              <p className="font-semibold text-red-700 text-sm">No emergency contacts!</p>
              <p className="text-red-600 text-xs">Add contacts so SOS alerts can be sent.</p>
            </div>
          </div>
          <button onClick={() => navigate('/profile')} className="text-xs bg-red-600 text-white px-3 py-1.5 rounded-lg font-medium">
            Add Now
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: SOS + Map */}
        <div className="lg:col-span-2 space-y-4">
          {/* Map */}
          <div className="card p-0 overflow-hidden">
            <div className="h-72 md:h-96">
              <MapComponent
                currentPosition={position}
                origin={activeJourney?.origin}
                destination={activeJourney?.destination}
                liveTrail={activeJourney?.liveCoordinates?.slice(-20) || []}
                riskLevel={activeJourney?.riskScore?.level}
              />
            </div>
          </div>

          {/* Active journey card */}
          {activeJourney ? (
            <div className="card border-rose-100 bg-rose-50">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-2 h-2 bg-rose-500 rounded-full animate-pulse"></div>
                    <span className="text-xs font-semibold text-rose-600 uppercase tracking-wide">Active Journey</span>
                  </div>
                  <p className="text-sm text-gray-700">
                    From: {activeJourney.origin?.address || `${activeJourney.origin?.lat?.toFixed(4)}, ${activeJourney.origin?.lng?.toFixed(4)}`}
                  </p>
                  {activeJourney.destination && (
                    <p className="text-sm text-gray-700 mt-0.5">
                      To: {activeJourney.destination?.address || 'Set destination'}
                    </p>
                  )}
                  {activeJourney.riskScore && (
                    <div className={`inline-flex items-center gap-1 mt-2 px-2 py-0.5 rounded-full text-xs font-semibold ${
                      activeJourney.riskScore.level === 'Safe' ? 'bg-emerald-100 text-emerald-700' :
                      activeJourney.riskScore.level === 'Moderate' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      Risk: {activeJourney.riskScore.score}/100 — {activeJourney.riskScore.level}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => navigate('/journey')}
                  className="text-xs bg-rose-600 text-white px-3 py-1.5 rounded-lg"
                >
                  View
                </button>
              </div>
            </div>
          ) : (
            <div className="card text-center py-6">
              <p className="text-gray-400 text-4xl mb-2">🗺️</p>
              <p className="text-gray-600 font-medium">No active journey</p>
              <button onClick={() => navigate('/journey')} className="mt-3 btn-primary text-sm px-4 py-2">
                Start Journey
              </button>
            </div>
          )}
        </div>

        {/* Right column: SOS + Stats */}
        <div className="space-y-4">
          {/* SOS */}
          <div className="card flex flex-col items-center py-6">
            <p className="text-sm font-semibold text-gray-600 mb-4 uppercase tracking-wide">Emergency SOS</p>
            <SOSButton
              journeyId={activeJourney?._id}
              position={position}
              onSOSTriggered={fetchData}
            />
          </div>

          {/* Quick stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="card text-center">
              <p className="text-2xl font-black text-rose-600">{user?.emergencyContacts?.length || 0}</p>
              <p className="text-xs text-gray-500 mt-1">Emergency<br />Contacts</p>
            </div>
            <div className="card text-center">
              <p className={`text-2xl font-black ${isTracking ? 'text-emerald-500' : 'text-gray-400'}`}>
                {isTracking ? '●' : '○'}
              </p>
              <p className="text-xs text-gray-500 mt-1">{isTracking ? 'Live' : 'Offline'}<br />Tracking</p>
            </div>
          </div>

          {/* Recent Alerts */}
          <div className="card">
            <h3 className="font-semibold text-gray-800 text-sm mb-3">Recent Alerts</h3>
            {recentAlerts.length === 0 ? (
              <p className="text-gray-400 text-xs text-center py-3">No alerts yet. Stay safe! ✅</p>
            ) : (
              <div className="space-y-2">
                {recentAlerts.map((alert) => (
                  <div key={alert._id} className="flex items-center gap-2 text-xs">
                    <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                      alert.status === 'active' ? 'bg-red-500' :
                      alert.status === 'resolved' ? 'bg-emerald-500' : 'bg-amber-500'
                    }`}></span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-700 truncate">{alert.type} Alert</p>
                      <p className="text-gray-400">{new Date(alert.createdAt).toLocaleDateString()}</p>
                    </div>
                    <span className={`shrink-0 px-1.5 py-0.5 rounded text-xs font-medium ${
                      alert.status === 'active' ? 'bg-red-100 text-red-600' :
                      alert.status === 'resolved' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'
                    }`}>{alert.status}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
