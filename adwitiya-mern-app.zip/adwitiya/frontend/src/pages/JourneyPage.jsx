import React, { useState, useEffect, useCallback } from 'react';
import MapComponent from '../components/MapComponent';
import RiskScoreCard from '../components/RiskScoreCard';
import SOSButton from '../components/SOSButton';
import { useGeolocation } from '../hooks/useGeolocation';
import api from '../services/api';
import toast from 'react-hot-toast';

export default function JourneyPage() {
  const [activeJourney, setActiveJourney] = useState(null);
  const [riskData, setRiskData] = useState(null);
  const [riskLoading, setRiskLoading] = useState(false);
  const [journeyLoading, setJourneyLoading] = useState(false);
  const [destInput, setDestInput] = useState('');
  const [origin, setOrigin] = useState(null);
  const [destination, setDestination] = useState(null);

  const { position, isTracking, getCurrentPosition } = useGeolocation(
    activeJourney?._id,
    !!activeJourney
  );

  const fetchActiveJourney = useCallback(async () => {
    try {
      const { data } = await api.get('/journey/active');
      if (data.journey) {
        setActiveJourney(data.journey);
        if (data.journey.riskScore) setRiskData(data.journey.riskScore);
      }
    } catch (err) {
      console.error(err);
    }
  }, []);

  useEffect(() => {
    fetchActiveJourney();
  }, [fetchActiveJourney]);

  // Update current position display
  useEffect(() => {
    if (position && !activeJourney) {
      setOrigin({ lat: position.latitude, lng: position.longitude });
    }
  }, [position, activeJourney]);

  const geocodeAddress = async (address) => {
    const res = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${process.env.REACT_APP_GOOGLE_MAPS_API_KEY}`
    );
    const data = await res.json();
    if (data.status === 'OK' && data.results.length > 0) {
      const { lat, lng } = data.results[0].geometry.location;
      return { lat, lng, address: data.results[0].formatted_address };
    }
    throw new Error('Address not found');
  };

  const handleCalculateRisk = async () => {
    if (!destInput.trim()) {
      toast.error('Enter a destination first');
      return;
    }

    setRiskLoading(true);
    try {
      let currentPos;
      try {
        currentPos = await getCurrentPosition();
      } catch {
        toast.error('Enable location to calculate risk');
        return;
      }

      const destCoords = await geocodeAddress(destInput);
      const originCoords = { lat: currentPos.latitude, lng: currentPos.longitude };

      setOrigin(originCoords);
      setDestination(destCoords);

      const { data } = await api.post('/risk/calculate', {
        origin: originCoords,
        destination: destCoords,
      });

      setRiskData(data);
      toast.success(`Risk calculated: ${data.level} (${data.riskScore}/100)`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to calculate risk');
    } finally {
      setRiskLoading(false);
    }
  };

  const handleStartJourney = async () => {
    setJourneyLoading(true);
    try {
      let currentPos;
      try {
        currentPos = await getCurrentPosition();
      } catch {
        toast.error('Enable location to start journey');
        return;
      }

      const originData = { lat: currentPos.latitude, lng: currentPos.longitude };
      const destData = destination;

      const { data } = await api.post('/journey/start', {
        origin: originData,
        destination: destData,
        notes: 'Journey started from Adwitiya app',
      });

      setActiveJourney(data.journey);
      if (data.journey.riskScore) setRiskData(data.journey.riskScore);
      toast.success('Journey started! You are now being tracked.');
    } catch (err) {
      toast.error('Failed to start journey');
    } finally {
      setJourneyLoading(false);
    }
  };

  const handleEndJourney = async () => {
    if (!activeJourney) return;
    try {
      await api.patch(`/journey/${activeJourney._id}/end`);
      setActiveJourney(null);
      setRiskData(null);
      toast.success('Journey ended. Stay safe! ✅');
    } catch (err) {
      toast.error('Failed to end journey');
    }
  };

  // Decode polyline for display
  const decodedPolyline = activeJourney?.routeData?.polyline
    ? decodePolyline(activeJourney.routeData.polyline)
    : riskData?.routeData?.polyline
    ? decodePolyline(riskData.routeData.polyline)
    : [];

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      <h1 className="text-2xl font-black text-gray-900 mb-6">Journey Planner</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map */}
        <div className="lg:col-span-2">
          <div className="card p-0 overflow-hidden h-96 md:h-[500px]">
            <MapComponent
              currentPosition={position}
              origin={origin || activeJourney?.origin}
              destination={destination || activeJourney?.destination}
              liveTrail={activeJourney?.liveCoordinates?.slice(-30) || []}
              polylinePath={decodedPolyline}
              riskLevel={riskData?.level}
            />
          </div>

          {/* Journey status bar */}
          {activeJourney && (
            <div className="mt-3 bg-rose-50 border border-rose-200 rounded-xl p-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 bg-rose-500 rounded-full animate-pulse"></div>
                <div>
                  <p className="font-semibold text-rose-700 text-sm">Journey Active</p>
                  <p className="text-xs text-rose-500">
                    Started {new Date(activeJourney.startTime).toLocaleTimeString()} •{' '}
                    {activeJourney.liveCoordinates?.length || 0} location updates
                  </p>
                </div>
              </div>
              <button
                onClick={handleEndJourney}
                className="text-xs bg-rose-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-rose-700"
              >
                End Journey
              </button>
            </div>
          )}
        </div>

        {/* Right panel */}
        <div className="space-y-4">
          {/* Destination input */}
          {!activeJourney && (
            <div className="card">
              <h3 className="font-semibold text-gray-800 mb-3">Plan Your Route</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">
                    📍 Origin (Current Location)
                  </label>
                  <div className="input-field bg-gray-50 text-gray-500 text-sm py-2">
                    {origin ? `${origin.lat.toFixed(4)}, ${origin.lng.toFixed(4)}` : 'Fetching location...'}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">
                    🎯 Destination
                  </label>
                  <input
                    className="input-field"
                    placeholder="Enter destination address..."
                    value={destInput}
                    onChange={(e) => setDestInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleCalculateRisk()}
                  />
                </div>

                <button
                  onClick={handleCalculateRisk}
                  disabled={riskLoading}
                  className="w-full btn-secondary"
                >
                  {riskLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></span>
                      Analyzing route...
                    </span>
                  ) : '🔍 Analyze Risk'}
                </button>

                {destination && (
                  <button
                    onClick={handleStartJourney}
                    disabled={journeyLoading}
                    className="w-full btn-primary"
                  >
                    {journeyLoading ? 'Starting...' : '🚀 Start Journey'}
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Risk Score */}
          <RiskScoreCard
            riskData={riskData}
            loading={riskLoading}
          />

          {/* SOS */}
          <div className="card flex flex-col items-center py-4">
            <p className="text-xs font-semibold text-gray-500 mb-4 uppercase tracking-wide">Emergency</p>
            <SOSButton
              journeyId={activeJourney?._id}
              position={position}
            />
          </div>

          {/* Live tracking indicator */}
          <div className={`card flex items-center gap-3 ${isTracking ? 'border-emerald-200 bg-emerald-50' : 'bg-gray-50'}`}>
            <div className={`w-3 h-3 rounded-full ${isTracking ? 'bg-emerald-500 animate-pulse' : 'bg-gray-300'}`}></div>
            <div>
              <p className={`text-sm font-semibold ${isTracking ? 'text-emerald-700' : 'text-gray-500'}`}>
                {isTracking ? 'Live Tracking Active' : 'Tracking Paused'}
              </p>
              <p className="text-xs text-gray-500">
                {isTracking ? 'Location sent every 5 seconds' : 'Start a journey to begin tracking'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Google Maps encoded polyline decoder
function decodePolyline(encoded) {
  const points = [];
  let index = 0, lat = 0, lng = 0;

  while (index < encoded.length) {
    let shift = 0, result = 0, byte;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20);
    lat += result & 1 ? ~(result >> 1) : result >> 1;

    shift = 0; result = 0;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20);
    lng += result & 1 ? ~(result >> 1) : result >> 1;

    points.push({ lat: lat / 1e5, lng: lng / 1e5 });
  }
  return points;
}
