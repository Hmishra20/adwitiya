import React, { useState, useEffect } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';

const statusColors = {
  active: 'bg-red-100 text-red-700 border-red-200',
  acknowledged: 'bg-amber-100 text-amber-700 border-amber-200',
  resolved: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  false_alarm: 'bg-gray-100 text-gray-600 border-gray-200',
};

const typeIcons = {
  SOS: '🆘',
  HIGH_RISK_ZONE: '⚠️',
  ROUTE_DEVIATION: '🔀',
  MANUAL: '📢',
};

export default function AlertsPage() {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({});
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchAlerts();
  }, [filter]);

  const fetchAlerts = async () => {
    setLoading(true);
    try {
      const params = filter !== 'all' ? `?status=${filter}` : '';
      const { data } = await api.get(`/alerts${params}`);
      setAlerts(data.alerts);
      setPagination(data.pagination);
    } catch (err) {
      toast.error('Failed to load alerts');
    } finally {
      setLoading(false);
    }
  };

  const handleResolve = async (alertId) => {
    try {
      await api.patch(`/alerts/${alertId}/resolve`);
      toast.success('Alert resolved');
      fetchAlerts();
    } catch (err) {
      toast.error('Failed to resolve alert');
    }
  };

  const openMaps = (lat, lng) => {
    window.open(`https://maps.google.com/?q=${lat},${lng}`, '_blank');
  };

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-black text-gray-900">Alert History</h1>
          <p className="text-gray-500 text-sm mt-1">All your emergency alerts</p>
        </div>
        {pagination.total > 0 && (
          <span className="bg-rose-100 text-rose-700 text-sm font-semibold px-3 py-1 rounded-full">
            {pagination.total} total
          </span>
        )}
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 mb-5 overflow-x-auto pb-1">
        {['all', 'active', 'acknowledged', 'resolved'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              filter === f
                ? 'bg-rose-600 text-white'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="card animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-1/3 mb-3"></div>
              <div className="h-3 bg-gray-200 rounded w-2/3 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2"></div>
            </div>
          ))}
        </div>
      ) : alerts.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <p className="text-5xl mb-4">✅</p>
          <p className="text-lg font-semibold">No alerts found</p>
          <p className="text-sm mt-1">Stay safe and alert-free!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert) => (
            <div key={alert._id} className="card hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <span className="text-2xl shrink-0">{typeIcons[alert.type] || '🔔'}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <p className="font-semibold text-gray-800 text-sm">{alert.type} Alert</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${statusColors[alert.status]}`}>
                        {alert.status}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500">
                      {new Date(alert.createdAt).toLocaleString()}
                    </p>
                    {alert.message && (
                      <p className="text-sm text-gray-600 mt-1">{alert.message}</p>
                    )}

                    {/* Notification status */}
                    <div className="flex gap-3 mt-2">
                      <span className={`text-xs flex items-center gap-1 ${alert.notificationsSent?.sms?.sent ? 'text-emerald-600' : 'text-gray-400'}`}>
                        📱 SMS {alert.notificationsSent?.sms?.sent ? '✓' : '✗'}
                      </span>
                      <span className={`text-xs flex items-center gap-1 ${alert.notificationsSent?.email?.sent ? 'text-emerald-600' : 'text-gray-400'}`}>
                        📧 Email {alert.notificationsSent?.email?.sent ? '✓' : '✗'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-2 shrink-0">
                  <button
                    onClick={() => openMaps(alert.location.lat, alert.location.lng)}
                    className="text-xs text-blue-600 hover:underline font-medium"
                  >
                    📍 View
                  </button>
                  {alert.status === 'active' && (
                    <button
                      onClick={() => handleResolve(alert._id)}
                      className="text-xs bg-emerald-600 text-white px-2 py-1 rounded font-medium hover:bg-emerald-700"
                    >
                      Resolve
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
