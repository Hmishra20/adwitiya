import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const { user } = useAuth();
  const [contacts, setContacts] = useState(user?.emergencyContacts || []);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('contacts');

  const handleContactChange = (idx, field, value) => {
    const updated = [...contacts];
    updated[idx] = { ...updated[idx], [field]: value };
    setContacts(updated);
  };

  const addContact = () => {
    if (contacts.length < 5) {
      setContacts([...contacts, { name: '', phone: '', email: '', relation: '' }]);
    }
  };

  const removeContact = (idx) => {
    setContacts(contacts.filter((_, i) => i !== idx));
  };

  const handleSaveContacts = async () => {
    setSaving(true);
    try {
      const valid = contacts.filter((c) => c.name.trim() && c.phone.trim());
      await api.put('/auth/emergency-contacts', { emergencyContacts: valid });
      toast.success('Emergency contacts updated!');
    } catch (err) {
      toast.error('Failed to update contacts');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-black text-gray-900 mb-6">Profile</h1>

      {/* User info card */}
      <div className="card mb-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-rose-100 rounded-full flex items-center justify-center text-rose-600 font-black text-2xl">
            {user?.name?.[0]?.toUpperCase()}
          </div>
          <div>
            <p className="font-bold text-gray-900 text-lg">{user?.name}</p>
            <p className="text-gray-500 text-sm">{user?.email}</p>
            <p className="text-gray-500 text-sm">{user?.phone}</p>
          </div>
        </div>
      </div>

      {/* Tab navigation */}
      <div className="flex border-b border-gray-200 mb-5">
        {['contacts', 'settings'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
              activeTab === tab
                ? 'border-rose-600 text-rose-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            {tab === 'contacts' ? '👥 Emergency Contacts' : '⚙️ Settings'}
          </button>
        ))}
      </div>

      {activeTab === 'contacts' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="font-semibold text-gray-700">Emergency Contacts</p>
              <p className="text-xs text-gray-500">These people will be notified via SMS & email when you trigger SOS</p>
            </div>
            {contacts.length < 5 && (
              <button onClick={addContact} className="text-sm text-rose-600 font-semibold hover:underline">
                + Add
              </button>
            )}
          </div>

          {contacts.length === 0 ? (
            <div className="text-center py-8 border-2 border-dashed border-gray-200 rounded-xl">
              <p className="text-3xl mb-2">👥</p>
              <p className="text-gray-500 text-sm">No emergency contacts yet</p>
              <button onClick={addContact} className="mt-3 btn-primary text-sm px-4 py-2">
                Add First Contact
              </button>
            </div>
          ) : (
            <div className="space-y-3 mb-5">
              {contacts.map((c, idx) => (
                <div key={idx} className="card border-gray-100">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-gray-500 uppercase">Contact {idx + 1}</span>
                    <button
                      onClick={() => removeContact(idx)}
                      className="text-red-400 hover:text-red-600 text-xs"
                    >
                      Remove
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs text-gray-500 mb-0.5 block">Name *</label>
                      <input
                        className="input-field text-sm"
                        placeholder="Full Name"
                        value={c.name}
                        onChange={(e) => handleContactChange(idx, 'name', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-0.5 block">Relation</label>
                      <input
                        className="input-field text-sm"
                        placeholder="e.g. Mom, Friend"
                        value={c.relation || ''}
                        onChange={(e) => handleContactChange(idx, 'relation', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-0.5 block">Phone * (for SMS)</label>
                      <input
                        className="input-field text-sm"
                        placeholder="+91 9876543210"
                        value={c.phone}
                        onChange={(e) => handleContactChange(idx, 'phone', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-0.5 block">Email (for alerts)</label>
                      <input
                        className="input-field text-sm"
                        placeholder="contact@email.com"
                        value={c.email || ''}
                        onChange={(e) => handleContactChange(idx, 'email', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {contacts.length > 0 && (
            <button
              onClick={handleSaveContacts}
              disabled={saving}
              className="w-full btn-primary py-3"
            >
              {saving ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  Saving...
                </span>
              ) : 'Save Emergency Contacts'}
            </button>
          )}
        </div>
      )}

      {activeTab === 'settings' && (
        <div className="space-y-4">
          <div className="card">
            <h3 className="font-semibold text-gray-800 mb-3">Safety Preferences</h3>
            <div className="space-y-3">
              {[
                { label: 'Night-time alerts', desc: 'Higher risk multiplier 8PM–6AM', enabled: true },
                { label: 'Auto-track on journey', desc: 'Start GPS tracking when journey begins', enabled: true },
                { label: 'SOS hold confirmation', desc: 'Require 3-second hold before SOS', enabled: true },
              ].map((pref) => (
                <div key={pref.label} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                  <div>
                    <p className="text-sm font-medium text-gray-700">{pref.label}</p>
                    <p className="text-xs text-gray-500">{pref.desc}</p>
                  </div>
                  <div className={`w-10 h-5 rounded-full relative cursor-pointer ${pref.enabled ? 'bg-rose-500' : 'bg-gray-300'}`}>
                    <div className={`w-4 h-4 bg-white rounded-full absolute top-0.5 transition-all ${pref.enabled ? 'right-0.5' : 'left-0.5'}`}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card bg-rose-50 border-rose-200">
            <h3 className="font-semibold text-rose-700 mb-2">Emergency Numbers</h3>
            <div className="space-y-2">
              {[
                { label: 'Police', number: '100' },
                { label: 'Women Helpline', number: '1091' },
                { label: 'Ambulance', number: '102' },
                { label: 'Emergency', number: '112' },
              ].map((e) => (
                <div key={e.label} className="flex items-center justify-between text-sm">
                  <span className="text-rose-700">{e.label}</span>
                  <a href={`tel:${e.number}`} className="font-bold text-rose-600 hover:underline">
                    {e.number}
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
