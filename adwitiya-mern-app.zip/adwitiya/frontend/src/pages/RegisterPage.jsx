import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function RegisterPage() {
  const { register } = useAuth();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: '', email: '', phone: '', password: '',
    emergencyContacts: [{ name: '', phone: '', email: '', relation: '' }],
  });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleContactChange = (idx, field, value) => {
    const contacts = [...form.emergencyContacts];
    contacts[idx] = { ...contacts[idx], [field]: value };
    setForm({ ...form, emergencyContacts: contacts });
  };

  const addContact = () => {
    if (form.emergencyContacts.length < 3) {
      setForm({ ...form, emergencyContacts: [...form.emergencyContacts, { name: '', phone: '', email: '', relation: '' }] });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const filteredContacts = form.emergencyContacts.filter((c) => c.name && c.phone);
      await register({ ...form, emergencyContacts: filteredContacts });
      toast.success('Account created! Stay safe!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-100 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        <div className="text-center mb-6">
          <div className="w-14 h-14 bg-rose-600 rounded-2xl flex items-center justify-center text-white text-2xl font-black mx-auto mb-3 shadow-lg shadow-rose-200">
            A
          </div>
          <h1 className="text-2xl font-black text-gray-900">Join Adwitiya</h1>
          <p className="text-gray-500 text-sm">Your safety, our mission</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input name="name" className="input-field" placeholder="Priya Sharma" value={form.name} onChange={handleChange} required />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input name="phone" className="input-field" placeholder="+91 9876543210" value={form.phone} onChange={handleChange} required />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input name="email" type="email" className="input-field" placeholder="priya@example.com" value={form.email} onChange={handleChange} required />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input name="password" type="password" className="input-field" placeholder="Min. 6 characters" value={form.password} onChange={handleChange} required minLength={6} />
            </div>

            {/* Emergency Contacts */}
            <div className="border-t pt-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="font-semibold text-gray-800 text-sm">Emergency Contacts</p>
                  <p className="text-xs text-gray-500">People to notify in SOS</p>
                </div>
                {form.emergencyContacts.length < 3 && (
                  <button type="button" onClick={addContact} className="text-xs text-rose-600 font-medium hover:underline">
                    + Add
                  </button>
                )}
              </div>

              {form.emergencyContacts.map((c, idx) => (
                <div key={idx} className="bg-gray-50 rounded-lg p-3 mb-2 space-y-2">
                  <p className="text-xs font-medium text-gray-500">Contact {idx + 1}</p>
                  <div className="grid grid-cols-2 gap-2">
                    <input className="input-field text-sm" placeholder="Name" value={c.name} onChange={(e) => handleContactChange(idx, 'name', e.target.value)} />
                    <input className="input-field text-sm" placeholder="Relation" value={c.relation} onChange={(e) => handleContactChange(idx, 'relation', e.target.value)} />
                    <input className="input-field text-sm" placeholder="Phone (+91...)" value={c.phone} onChange={(e) => handleContactChange(idx, 'phone', e.target.value)} />
                    <input className="input-field text-sm" placeholder="Email" value={c.email} onChange={(e) => handleContactChange(idx, 'email', e.target.value)} />
                  </div>
                </div>
              ))}
            </div>

            <button type="submit" disabled={loading} className="w-full btn-primary py-3">
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  Creating account...
                </span>
              ) : 'Create Account'}
            </button>
          </form>

          <p className="text-center text-sm text-gray-500 mt-4">
            Already have an account?{' '}
            <Link to="/login" className="text-rose-600 font-semibold hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
