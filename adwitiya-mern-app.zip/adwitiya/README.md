# 🛡️ Adwitiya — Women & Student Safety App

> **"Adwitiya" (अद्वितीया)** — Sanskrit for *unique, unparalleled*. Because every person's safety is irreplaceable.

A production-ready MERN stack safety application featuring real-time location tracking, AI-powered route risk scoring, SOS emergency alerts via Twilio SMS + SendGrid Email, and Google Maps integration.

---

## 🏗️ Architecture

```
adwitiya/
├── backend/                    # Node.js + Express API
│   ├── config/
│   │   └── db.js               # MongoDB connection
│   ├── controllers/
│   │   ├── authController.js   # JWT auth (register/login)
│   │   ├── alertController.js  # SOS + alert management
│   │   ├── journeyController.js# Journey CRUD
│   │   ├── locationController.js# Live location updates
│   │   └── riskController.js   # Risk score endpoint
│   ├── middleware/
│   │   ├── auth.js             # JWT protect + restrictTo
│   │   └── errorHandler.js     # Global error handler
│   ├── models/
│   │   ├── User.js             # User schema + emergency contacts
│   │   ├── Journey.js          # Journey + live coordinates
│   │   └── Alert.js            # SOS + alert records
│   ├── routes/                 # Express route definitions
│   ├── services/
│   │   ├── riskService.js      # Google Maps/Places + risk algorithm
│   │   └── notificationService.js # Twilio SMS + SendGrid Email
│   ├── utils/
│   │   └── logger.js           # Winston logger
│   ├── server.js               # Express entry point
│   ├── render.yaml             # Render deployment config
│   └── .env.example
│
└── frontend/                   # React.js + Tailwind CSS
    ├── src/
    │   ├── components/
    │   │   ├── Layout.jsx          # Sidebar navigation
    │   │   ├── MapComponent.jsx    # Google Maps with route + trail
    │   │   ├── SOSButton.jsx       # 3-second hold SOS with animation
    │   │   └── RiskScoreCard.jsx   # Dynamic risk visualization
    │   ├── context/
    │   │   └── AuthContext.jsx     # Global auth state
    │   ├── hooks/
    │   │   └── useGeolocation.js   # GPS tracking + 5s backend sync
    │   ├── pages/
    │   │   ├── LoginPage.jsx
    │   │   ├── RegisterPage.jsx
    │   │   ├── DashboardPage.jsx   # Overview + quick SOS
    │   │   ├── JourneyPage.jsx     # Route planner + live map
    │   │   ├── AlertsPage.jsx      # Alert history
    │   │   └── ProfilePage.jsx     # Emergency contacts management
    │   ├── services/
    │   │   └── api.js              # Axios instance + interceptors
    │   └── App.jsx
    ├── vercel.json             # Vercel deployment config
    └── .env.example
```

---

## 🚀 Features

### ✅ Route Risk Scoring System
- **Google Maps Directions API** for route generation (distance, duration, polyline)
- **Google Places API** to count nearby police stations, hospitals, pharmacies, etc.
- **4-factor risk algorithm:**
  - Distance factor (0–50 pts)
  - Travel time factor (0–50 pts)
  - Isolation factor (0–70 pts based on POI count)
  - Night-time multiplier (1.0x → 1.8x between 8PM–5AM)
- Dynamic score 0–100 → **Safe / Moderate / High**

### ✅ Real-Time Location Tracking
- Browser Geolocation API with `watchPosition`
- Sends live coordinates to backend every **5 seconds**
- Stores timestamped coordinates in MongoDB (last 500 per journey)
- Admin live tracking endpoint with trail visualization

### ✅ SOS Emergency System
- **3-second hold** to prevent accidental triggers
- Triggers simultaneously:
  - Saves alert to MongoDB with full metadata
  - Sends SMS via **Twilio** to all emergency contacts
  - Sends HTML email via **SendGrid** with Google Maps link
- Returns confirmation with notification delivery status

### ✅ JWT Authentication
- Bcrypt password hashing (salt rounds: 12)
- JWT with configurable expiry
- Protected routes middleware
- Role-based access (user/admin)

---

## 🛠️ Setup & Installation

### Prerequisites
- Node.js 18+
- MongoDB Atlas account (free tier works)
- Google Cloud account (Maps + Places APIs enabled)
- Twilio account (trial works for testing)
- SendGrid account (free tier: 100 emails/day)

### Backend Setup

```bash
cd backend
npm install
cp .env.example .env
# Fill in all API keys in .env
npm run dev
```

### Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env
# Add REACT_APP_API_URL and REACT_APP_GOOGLE_MAPS_API_KEY
npm start
```

---

## 📋 Environment Variables

### Backend `.env`

| Variable | Description |
|----------|-------------|
| `MONGO_URI` | MongoDB Atlas connection string |
| `JWT_SECRET` | Random string ≥32 chars |
| `GOOGLE_MAPS_API_KEY` | Enable Directions API |
| `GOOGLE_PLACES_API_KEY` | Enable Places API (Nearby Search) |
| `TWILIO_ACCOUNT_SID` | Twilio Console |
| `TWILIO_AUTH_TOKEN` | Twilio Console |
| `TWILIO_PHONE_NUMBER` | Your Twilio phone number |
| `SENDGRID_API_KEY` | SendGrid → API Keys |
| `SENDGRID_FROM_EMAIL` | Verified sender email |
| `CLIENT_URL` | Frontend URL for CORS |

### Frontend `.env`

| Variable | Description |
|----------|-------------|
| `REACT_APP_API_URL` | Backend API URL |
| `REACT_APP_GOOGLE_MAPS_API_KEY` | Same key (or separate) |

---

## 🌐 API Reference

### Auth
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/auth/register` | Register user |
| POST | `/api/auth/login` | Login → JWT |
| GET | `/api/auth/me` | Get current user |
| PUT | `/api/auth/emergency-contacts` | Update contacts |

### Risk
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/risk/calculate` | Calculate route risk score |

### Journey
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/journey/start` | Start new journey |
| GET | `/api/journey/active` | Get active journey |
| GET | `/api/journey` | Journey history |
| PATCH | `/api/journey/:id/end` | End journey |

### Location
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/location/update` | Send live coordinates |
| GET | `/api/location/live/:journeyId` | Get live tracking data |
| GET | `/api/location/active-users` | Admin: all active users |

### Alerts
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/alerts/sos` | **Trigger SOS** |
| GET | `/api/alerts` | Get alert history |
| PATCH | `/api/alerts/:id/resolve` | Resolve alert |

---

## 🚀 Deployment

### Backend → Render

1. Create account at [render.com](https://render.com)
2. New → Web Service → Connect your GitHub repo
3. Root directory: `backend`
4. Build command: `npm install`
5. Start command: `npm start`
6. Add all environment variables from `.env.example`
7. Deploy!

### Frontend → Vercel

```bash
cd frontend
npm install -g vercel
vercel login
vercel --prod
# Set environment variables in Vercel dashboard
```

Or connect GitHub repo to Vercel for automatic deployments.

---

## 🔒 Security Features

- Helmet.js for HTTP headers
- CORS configured per origin
- Rate limiting: 100 req/15min (global), 10/5min (SOS)
- JWT token validation on all protected routes
- Input validation with express-validator
- Password hashing with bcrypt (12 rounds)
- Environment variables for all secrets
- Request size limiting (10kb max body)

---

## 🧪 Testing SOS (Development)

1. Register with emergency contacts (include your own phone/email for testing)
2. In Twilio trial: add your phone number to "Verified Caller IDs"
3. Open Journey page → Start a journey
4. Hold SOS button for 3 seconds
5. Check your phone for SMS and email for alert

---

## 📱 Emergency Numbers (India)

| Service | Number |
|---------|--------|
| Police | 100 |
| Women Helpline | 1091 |
| Ambulance | 102 |
| National Emergency | 112 |

---

## 🏆 Built For

This MVP was built for hackathon demonstration showcasing real-world API integrations, scalable architecture, and genuine safety utility for women and students.

**Stack:** MongoDB · Express.js · React.js · Node.js · Google Maps · Twilio · SendGrid · JWT · Tailwind CSS

---

*Stay safe. Be Adwitiya.* 🛡️
