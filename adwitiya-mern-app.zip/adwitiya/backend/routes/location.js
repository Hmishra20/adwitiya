const express = require('express');
const { updateLocation, getLiveLocation, getActiveUsers } = require('../controllers/locationController');
const { protect, restrictTo } = require('../middleware/auth');

const router = express.Router();
router.use(protect);

router.post('/update', updateLocation);
router.get('/live/:journeyId', getLiveLocation);
router.get('/active-users', restrictTo('admin'), getActiveUsers);

module.exports = router;
