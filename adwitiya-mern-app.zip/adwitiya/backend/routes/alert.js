const express = require('express');
const { triggerSOS, getAlerts, acknowledgeAlert, resolveAlert } = require('../controllers/alertController');
const { protect, restrictTo } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.post('/sos', triggerSOS);
router.get('/', getAlerts);
router.patch('/:id/acknowledge', restrictTo('admin'), acknowledgeAlert);
router.patch('/:id/resolve', resolveAlert);

module.exports = router;
