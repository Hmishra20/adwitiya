const express = require('express');
const { calculateRisk } = require('../controllers/riskController');
const { protect } = require('../middleware/auth');

const router = express.Router();
router.use(protect);
router.post('/calculate', calculateRisk);

module.exports = router;
