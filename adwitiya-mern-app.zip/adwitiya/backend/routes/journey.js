const express = require('express');
const { startJourney, endJourney, getJourneys, getActiveJourney, getJourneyById } = require('../controllers/journeyController');
const { protect } = require('../middleware/auth');

const router = express.Router();
router.use(protect);

router.post('/start', startJourney);
router.get('/active', getActiveJourney);
router.get('/', getJourneys);
router.get('/:id', getJourneyById);
router.patch('/:id/end', endJourney);

module.exports = router;
