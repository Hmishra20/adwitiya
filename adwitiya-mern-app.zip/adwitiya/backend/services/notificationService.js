const twilio = require('twilio');
const sgMail = require('@sendgrid/mail');
const logger = require('../utils/logger');

// Initialize Twilio
const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// Initialize SendGrid
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

/**
 * Send SMS via Twilio
 */
const sendSMS = async (to, message) => {
  try {
    const result = await twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to,
    });
    logger.info(`SMS sent to ${to}, SID: ${result.sid}`);
    return { success: true, sid: result.sid };
  } catch (error) {
    logger.error(`SMS send error to ${to}: ${error.message}`);
    return { success: false, error: error.message };
  }
};

/**
 * Send SOS SMS to all emergency contacts
 */
const sendSOSSMS = async (user, location, alertId) => {
  const mapsLink = `https://maps.google.com/?q=${location.lat},${location.lng}`;
  const message = `🚨 SOS ALERT from ${user.name}!\n\nThey need immediate help.\n📍 Location: ${mapsLink}\n⏰ Time: ${new Date().toLocaleString()}\n\nAlert ID: ${alertId}\n\n- Adwitiya Safety App`;

  const recipients = user.emergencyContacts
    .filter((c) => c.phone)
    .map((c) => c.phone);

  if (recipients.length === 0) {
    logger.warn(`No emergency contacts with phone for user ${user._id}`);
    return { success: false, recipients: [], error: 'No phone contacts found' };
  }

  const results = await Promise.allSettled(recipients.map((phone) => sendSMS(phone, message)));
  const successful = results.filter((r) => r.status === 'fulfilled' && r.value.success).length;

  return {
    success: successful > 0,
    recipients,
    sentCount: successful,
  };
};

/**
 * Send SOS Email via SendGrid
 */
const sendSOSEmail = async (user, location, alertId) => {
  const mapsLink = `https://maps.google.com/?q=${location.lat},${location.lng}`;
  const recipients = user.emergencyContacts.filter((c) => c.email).map((c) => c.email);

  if (recipients.length === 0) {
    logger.warn(`No emergency contacts with email for user ${user._id}`);
    return { success: false, recipients: [], error: 'No email contacts found' };
  }

  const emailBody = {
    to: recipients,
    from: {
      email: process.env.SENDGRID_FROM_EMAIL,
      name: process.env.SENDGRID_FROM_NAME || 'Adwitiya Safety Alert',
    },
    subject: `🚨 URGENT: SOS Alert from ${user.name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #fff;">
        <div style="background: #dc2626; padding: 24px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">🚨 SOS EMERGENCY ALERT</h1>
        </div>
        <div style="padding: 24px; border: 2px solid #dc2626; border-top: none; border-radius: 0 0 8px 8px;">
          <p style="font-size: 18px; font-weight: bold; color: #dc2626;">
            ${user.name} has triggered an SOS emergency alert!
          </p>
          <p style="color: #374151;">They may need immediate assistance. Please try to contact them or call emergency services.</p>
          
          <div style="background: #f9fafb; padding: 16px; border-radius: 8px; margin: 16px 0;">
            <h3 style="margin: 0 0 8px 0; color: #1f2937;">Alert Details</h3>
            <p style="margin: 4px 0;"><strong>Name:</strong> ${user.name}</p>
            <p style="margin: 4px 0;"><strong>Phone:</strong> ${user.phone || 'N/A'}</p>
            <p style="margin: 4px 0;"><strong>Alert Time:</strong> ${new Date().toLocaleString()}</p>
            <p style="margin: 4px 0;"><strong>Alert ID:</strong> ${alertId}</p>
          </div>

          <div style="text-align: center; margin: 24px 0;">
            <a href="${mapsLink}" 
               style="background: #dc2626; color: white; padding: 12px 32px; 
                      text-decoration: none; border-radius: 8px; font-size: 16px; font-weight: bold;">
              📍 View Location on Map
            </a>
          </div>

          <p style="color: #6b7280; font-size: 12px; text-align: center; margin-top: 24px;">
            This is an automated alert from Adwitiya Safety App. Do not reply to this email.
          </p>
        </div>
      </div>
    `,
  };

  try {
    await sgMail.send(emailBody);
    logger.info(`SOS email sent to ${recipients.join(', ')}`);
    return { success: true, recipients, sentCount: recipients.length };
  } catch (error) {
    logger.error(`SendGrid error: ${error.message}`);
    return { success: false, recipients, error: error.message };
  }
};

module.exports = { sendSMS, sendSOSSMS, sendSOSEmail };
