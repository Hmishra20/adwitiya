const axios = require('axios');
const logger = require('../utils/logger');

const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;
const GOOGLE_PLACES_API_KEY = process.env.GOOGLE_PLACES_API_KEY;

/**
 * Fetch route data from Google Maps Directions API
 */
const getRouteData = async (origin, destination) => {
  const url = `https://maps.googleapis.com/maps/api/directions/json`;
  const response = await axios.get(url, {
    params: {
      origin: `${origin.lat},${origin.lng}`,
      destination: `${destination.lat},${destination.lng}`,
      key: GOOGLE_MAPS_API_KEY,
      mode: 'walking',
    },
    timeout: 8000,
  });

  const data = response.data;
  if (data.status !== 'OK' || !data.routes.length) {
    throw new Error(`Directions API error: ${data.status}`);
  }

  const route = data.routes[0];
  const leg = route.legs[0];

  return {
    distance: leg.distance.text,
    distanceValue: leg.distance.value, // meters
    duration: leg.duration.text,
    durationValue: leg.duration.value, // seconds
    polyline: route.overview_polyline.encoded,
    startAddress: leg.start_address,
    endAddress: leg.end_address,
  };
};

/**
 * Fetch nearby POIs using Google Places API
 */
const getNearbyPOIs = async (lat, lng, radius = 500) => {
  const safePlaceTypes = [
    'police',
    'hospital',
    'fire_station',
    'pharmacy',
    'convenience_store',
    'shopping_mall',
    'restaurant',
    'bus_station',
    'train_station',
    'bank',
  ];

  const requests = safePlaceTypes.slice(0, 3).map((type) =>
    axios.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json', {
      params: {
        location: `${lat},${lng}`,
        radius,
        type,
        key: GOOGLE_PLACES_API_KEY,
      },
      timeout: 8000,
    })
  );

  const results = await Promise.allSettled(requests);
  let totalPOIs = 0;
  const poiDetails = {};

  safePlaceTypes.slice(0, 3).forEach((type, i) => {
    if (results[i].status === 'fulfilled') {
      const count = results[i].value.data.results?.length || 0;
      poiDetails[type] = count;
      totalPOIs += count;
    }
  });

  return { totalPOIs, poiDetails };
};

/**
 * Calculate isolation factor: fewer POIs = higher isolation = higher risk
 */
const calcIsolationFactor = (totalPOIs) => {
  if (totalPOIs >= 10) return 0;
  if (totalPOIs >= 5) return 15;
  if (totalPOIs >= 2) return 30;
  if (totalPOIs === 1) return 50;
  return 70; // completely isolated
};

/**
 * Calculate distance factor: longer = higher risk
 */
const calcDistanceFactor = (distanceMeters) => {
  if (distanceMeters < 500) return 5;
  if (distanceMeters < 1500) return 15;
  if (distanceMeters < 3000) return 25;
  if (distanceMeters < 5000) return 35;
  return 50;
};

/**
 * Calculate time factor: longer duration = more exposure
 */
const calcTimeFactor = (durationSeconds) => {
  const minutes = durationSeconds / 60;
  if (minutes < 5) return 5;
  if (minutes < 15) return 10;
  if (minutes < 30) return 20;
  if (minutes < 60) return 35;
  return 50;
};

/**
 * Night-time multiplier (6 PM – 6 AM = higher risk)
 */
const getNightMultiplier = () => {
  const hour = new Date().getHours();
  if (hour >= 22 || hour < 5) return 1.8; // Very late / early morning
  if (hour >= 20 || hour < 7) return 1.4; // Evening / early morning
  return 1.0;
};

/**
 * Main risk scoring function
 */
const calculateRiskScore = async (origin, destination) => {
  try {
    // Fetch route data
    const routeData = await getRouteData(origin, destination);

    // Fetch POIs near midpoint
    const midLat = (origin.lat + destination.lat) / 2;
    const midLng = (origin.lng + destination.lng) / 2;
    const { totalPOIs, poiDetails } = await getNearbyPOIs(midLat, midLng, 600);

    // Calculate individual factors
    const distanceFactor = calcDistanceFactor(routeData.distanceValue);
    const timeFactor = calcTimeFactor(routeData.durationValue);
    const isolationFactor = calcIsolationFactor(totalPOIs);
    const nightMultiplier = getNightMultiplier();

    // Raw score: weighted sum
    const rawScore = (distanceFactor * 0.2 + timeFactor * 0.2 + isolationFactor * 0.6);

    // Apply night multiplier and clamp 0-100
    const finalScore = Math.min(100, Math.round(rawScore * nightMultiplier));

    // Determine level
    let level;
    if (finalScore <= 35) level = 'Safe';
    else if (finalScore <= 65) level = 'Moderate';
    else level = 'High';

    return {
      score: finalScore,
      level,
      factors: {
        distanceFactor,
        timeFactor,
        isolationFactor,
        nightMultiplier,
        totalPOIsNearby: totalPOIs,
        poiDetails,
      },
      routeData,
      calculatedAt: new Date(),
    };
  } catch (error) {
    logger.error(`Risk calculation error: ${error.message}`);
    throw error;
  }
};

module.exports = { calculateRiskScore, getRouteData, getNearbyPOIs };
