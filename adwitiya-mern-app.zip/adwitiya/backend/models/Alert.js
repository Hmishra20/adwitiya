const mongoose = require('mongoose');

const AlertSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    journey: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Journey',
    },
    type: {
      type: String,
      enum: ['SOS', 'HIGH_RISK_ZONE', 'ROUTE_DEVIATION', 'MANUAL'],
      default: 'SOS',
    },
    status: {
      type: String,
      enum: ['active', 'acknowledged', 'resolved', 'false_alarm'],
      default: 'active',
    },
    location: {
      lat: { type: Number, required: true },
      lng: { type: Number, required: true },
      address: { type: String },
      accuracy: { type: Number },
    },
    message: { type: String, maxlength: 500 },
    notificationsSent: {
      sms: {
        sent: { type: Boolean, default: false },
        sentAt: { type: Date },
        recipients: [String],
        error: { type: String },
      },
      email: {
        sent: { type: Boolean, default: false },
        sentAt: { type: Date },
        recipients: [String],
        error: { type: String },
      },
    },
    acknowledgedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    acknowledgedAt: { type: Date },
    resolvedAt: { type: Date },
  },
  { timestamps: true }
);

AlertSchema.index({ user: 1, status: 1 });
AlertSchema.index({ createdAt: -1 });
AlertSchema.index({ location: '2dsphere' });

module.exports = mongoose.model('Alert', AlertSchema);
