const mongoose = require('mongoose');

const CoordinateSchema = new mongoose.Schema({
  lat: { type: Number, required: true },
  lng: { type: Number, required: true },
  timestamp: { type: Date, default: Date.now },
  accuracy: { type: Number },
});

const JourneySchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    status: {
      type: String,
      enum: ['active', 'completed', 'emergency', 'cancelled'],
      default: 'active',
    },
    origin: {
      address: { type: String },
      lat: { type: Number, required: true },
      lng: { type: Number, required: true },
    },
    destination: {
      address: { type: String },
      lat: { type: Number },
      lng: { type: Number },
    },
    routeData: {
      distance: { type: String }, // e.g., "3.2 km"
      duration: { type: String }, // e.g., "12 mins"
      polyline: { type: String }, // encoded polyline
    },
    riskScore: {
      score: { type: Number, min: 0, max: 100 },
      level: { type: String, enum: ['Safe', 'Moderate', 'High'] },
      factors: {
        distanceFactor: Number,
        timeFactor: Number,
        isolationFactor: Number,
        nightMultiplier: Number,
      },
      calculatedAt: { type: Date },
    },
    liveCoordinates: [CoordinateSchema],
    startTime: { type: Date, default: Date.now },
    endTime: { type: Date },
    expectedArrival: { type: Date },
    notes: { type: String, maxlength: 500 },
  },
  { timestamps: true }
);

JourneySchema.index({ user: 1, status: 1 });
JourneySchema.index({ createdAt: -1 });

module.exports = mongoose.model('Journey', JourneySchema);
