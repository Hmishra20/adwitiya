const Journey = require('../models/Journey');
const User = require('../models/User');
const logger = require('../utils/logger');

// @route POST /api/location/update
// Receives live coordinates every 5 seconds
exports.updateLocation = async (req, res, next) => {
  try {
    const { lat, lng, accuracy, journeyId } = req.body;

    if (!lat || !lng) {
      return res.status(400).json({ success: false, message: 'Coordinates required' });
    }

    const coordinate = { lat, lng, accuracy, timestamp: new Date() };

    // Update user's last known location
    await User.findByIdAndUpdate(req.user.id, {
      lastLocation: { type: 'Point', coordinates: [lng, lat] },
      lastSeen: new Date(),
    });

    // Append to journey's live coordinates if journeyId provided
    if (journeyId) {
      await Journey.findOneAndUpdate(
        { _id: journeyId, user: req.user.id, status: 'active' },
        {
          $push: {
            liveCoordinates: {
              $each: [coordinate],
              $slice: -500, // Keep last 500 coordinates (max ~41 min at 5s intervals)
            },
          },
        }
      );
    }

    res.json({ success: true, timestamp: coordinate.timestamp });
  } catch (error) {
    next(error);
  }
};

// @route GET /api/location/live/:journeyId
// Admin live tracking endpoint
exports.getLiveLocation = async (req, res, next) => {
  try {
    const journey = await Journey.findById(req.params.journeyId)
      .populate('user', 'name email phone')
      .select('status liveCoordinates user origin destination riskScore startTime');

    if (!journey) {
      return res.status(404).json({ success: false, message: 'Journey not found' });
    }

    // For non-admin, only show own journeys
    if (req.user.role !== 'admin' && journey.user._id.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    const latestCoord =
      journey.liveCoordinates.length > 0
        ? journey.liveCoordinates[journey.liveCoordinates.length - 1]
        : null;

    res.json({
      success: true,
      journey: {
        id: journey._id,
        user: journey.user,
        status: journey.status,
        latestLocation: latestCoord,
        coordinatesCount: journey.liveCoordinates.length,
        allCoordinates: journey.liveCoordinates.slice(-50), // Last 50 for trail
        riskScore: journey.riskScore,
        startTime: journey.startTime,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @route GET /api/location/active-users
// Admin: all users with active journeys
exports.getActiveUsers = async (req, res, next) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Admin access required' });
    }

    const activeJourneys = await Journey.find({ status: 'active' })
      .populate('user', 'name email phone lastSeen')
      .select('user liveCoordinates riskScore startTime')
      .sort({ createdAt: -1 })
      .limit(50);

    const users = activeJourneys.map((j) => {
      const latest =
        j.liveCoordinates.length > 0 ? j.liveCoordinates[j.liveCoordinates.length - 1] : null;
      return {
        journeyId: j._id,
        user: j.user,
        latestLocation: latest,
        riskScore: j.riskScore,
        startTime: j.startTime,
      };
    });

    res.json({ success: true, activeUsers: users, count: users.length });
  } catch (error) {
    next(error);
  }
};
