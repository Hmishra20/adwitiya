const Alert = require('../models/Alert');
const Journey = require('../models/Journey');
const User = require('../models/User');
const { sendSOSSMS, sendSOSEmail } = require('../services/notificationService');
const logger = require('../utils/logger');

// @route POST /api/alerts/sos
exports.triggerSOS = async (req, res, next) => {
  try {
    const { lat, lng, accuracy, journeyId, message } = req.body;

    if (!lat || !lng) {
      return res.status(400).json({ success: false, message: 'Location coordinates required' });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    // Create alert entry
    const alert = await Alert.create({
      user: user._id,
      journey: journeyId || null,
      type: 'SOS',
      status: 'active',
      location: { lat, lng, accuracy },
      message: message || 'SOS triggered by user',
    });

    // Send notifications concurrently
    const [smsResult, emailResult] = await Promise.all([
      sendSOSSMS(user, { lat, lng }, alert._id),
      sendSOSEmail(user, { lat, lng }, alert._id),
    ]);

    // Update alert with notification status
    alert.notificationsSent = {
      sms: {
        sent: smsResult.success,
        sentAt: smsResult.success ? new Date() : undefined,
        recipients: smsResult.recipients || [],
        error: smsResult.error,
      },
      email: {
        sent: emailResult.success,
        sentAt: emailResult.success ? new Date() : undefined,
        recipients: emailResult.recipients || [],
        error: emailResult.error,
      },
    };
    await alert.save();

    // Update journey status if active
    if (journeyId) {
      await Journey.findByIdAndUpdate(journeyId, { status: 'emergency' });
    }

    logger.warn(`SOS triggered by user ${user._id} at [${lat}, ${lng}]`);

    res.status(201).json({
      success: true,
      message: 'SOS alert triggered successfully',
      alert: {
        id: alert._id,
        location: alert.location,
        createdAt: alert.createdAt,
      },
      notifications: {
        sms: { sent: smsResult.success, count: smsResult.sentCount },
        email: { sent: emailResult.success, count: emailResult.sentCount },
      },
    });
  } catch (error) {
    next(error);
  }
};

// @route GET /api/alerts
exports.getAlerts = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    const filter = req.user.role === 'admin' ? {} : { user: req.user.id };
    if (req.query.status) filter.status = req.query.status;

    const [alerts, total] = await Promise.all([
      Alert.find(filter)
        .populate('user', 'name email phone')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Alert.countDocuments(filter),
    ]);

    res.json({
      success: true,
      alerts,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    next(error);
  }
};

// @route PATCH /api/alerts/:id/acknowledge
exports.acknowledgeAlert = async (req, res, next) => {
  try {
    const alert = await Alert.findById(req.params.id);
    if (!alert) {
      return res.status(404).json({ success: false, message: 'Alert not found' });
    }

    alert.status = 'acknowledged';
    alert.acknowledgedBy = req.user.id;
    alert.acknowledgedAt = new Date();
    await alert.save();

    res.json({ success: true, alert });
  } catch (error) {
    next(error);
  }
};

// @route PATCH /api/alerts/:id/resolve
exports.resolveAlert = async (req, res, next) => {
  try {
    const alert = await Alert.findByIdAndUpdate(
      req.params.id,
      { status: 'resolved', resolvedAt: new Date() },
      { new: true }
    );
    if (!alert) return res.status(404).json({ success: false, message: 'Alert not found' });
    res.json({ success: true, alert });
  } catch (error) {
    next(error);
  }
};
