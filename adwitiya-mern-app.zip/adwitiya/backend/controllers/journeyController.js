const Journey = require('../models/Journey');
const { calculateRiskScore } = require('../services/riskService');
const logger = require('../utils/logger');

// @route POST /api/journey/start
exports.startJourney = async (req, res, next) => {
  try {
    const { origin, destination, expectedArrival, notes } = req.body;

    if (!origin?.lat || !origin?.lng) {
      return res.status(400).json({ success: false, message: 'Origin coordinates required' });
    }

    // Calculate risk score if destination is provided
    let riskData = null;
    let routeData = null;

    if (destination?.lat && destination?.lng) {
      try {
        const result = await calculateRiskScore(origin, destination);
        riskData = {
          score: result.score,
          level: result.level,
          factors: result.factors,
          calculatedAt: result.calculatedAt,
        };
        routeData = {
          distance: result.routeData.distance,
          duration: result.routeData.duration,
          polyline: result.routeData.polyline,
        };
      } catch (err) {
        logger.warn(`Risk calculation skipped: ${err.message}`);
      }
    }

    const journey = await Journey.create({
      user: req.user.id,
      status: 'active',
      origin,
      destination,
      routeData,
      riskScore: riskData,
      expectedArrival,
      notes,
      liveCoordinates: [{ lat: origin.lat, lng: origin.lng }],
    });

    res.status(201).json({ success: true, journey });
  } catch (error) {
    next(error);
  }
};

// @route PATCH /api/journey/:id/end
exports.endJourney = async (req, res, next) => {
  try {
    const journey = await Journey.findOne({ _id: req.params.id, user: req.user.id });
    if (!journey) return res.status(404).json({ success: false, message: 'Journey not found' });

    journey.status = 'completed';
    journey.endTime = new Date();
    await journey.save();

    res.json({ success: true, journey });
  } catch (error) {
    next(error);
  }
};

// @route GET /api/journey
exports.getJourneys = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;

    const journeys = await Journey.find({ user: req.user.id })
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    const total = await Journey.countDocuments({ user: req.user.id });

    res.json({
      success: true,
      journeys,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    next(error);
  }
};

// @route GET /api/journey/active
exports.getActiveJourney = async (req, res, next) => {
  try {
    const journey = await Journey.findOne({ user: req.user.id, status: 'active' }).sort({
      createdAt: -1,
    });
    res.json({ success: true, journey });
  } catch (error) {
    next(error);
  }
};

// @route GET /api/journey/:id
exports.getJourneyById = async (req, res, next) => {
  try {
    const journey = await Journey.findOne({ _id: req.params.id, user: req.user.id });
    if (!journey) return res.status(404).json({ success: false, message: 'Journey not found' });
    res.json({ success: true, journey });
  } catch (error) {
    next(error);
  }
};
