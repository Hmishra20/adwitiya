const { calculateRiskScore } = require('../services/riskService');

// @route POST /api/risk/calculate
exports.calculateRisk = async (req, res, next) => {
  try {
    const { origin, destination } = req.body;

    if (!origin?.lat || !origin?.lng || !destination?.lat || !destination?.lng) {
      return res.status(400).json({
        success: false,
        message: 'Both origin and destination coordinates are required',
      });
    }

    const result = await calculateRiskScore(origin, destination);

    res.json({
      success: true,
      riskScore: result.score,
      level: result.level,
      factors: result.factors,
      routeData: result.routeData,
      calculatedAt: result.calculatedAt,
    });
  } catch (error) {
    next(error);
  }
};
